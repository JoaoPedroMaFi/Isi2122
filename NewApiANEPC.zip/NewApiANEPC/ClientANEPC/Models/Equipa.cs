﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientANEPC.Models
{
    public class Equipa
    {
        public int IdEquipa { get; set; }

        public int IdCidade { get; set; }

        public string NomeEquipa { get; set; }
    }
}
