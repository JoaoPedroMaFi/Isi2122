﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientANEPC.Models
{
    public class Produto
    {
        public int IdProduto { get; set; }

        public string Descricao { get; set; }

        public float Preco { get; set; }
    }
}
