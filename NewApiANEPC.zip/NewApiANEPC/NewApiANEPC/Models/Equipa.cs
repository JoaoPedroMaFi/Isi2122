﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewApiANEPC.Models
{
    public class Equipa
    {
        public int IdEquipa { get; set; }

        public int IdCidade { get; set; }

        public string NomeEquipa { get; set; }
    }
}
