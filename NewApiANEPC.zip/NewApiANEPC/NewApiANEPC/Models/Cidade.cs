﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewApiANEPC.Models
{
    public class Cidade
    {
        public int IdCidade { get; set; }
        public string CidadeNome { get; set; }
    }
}
