﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewApiANEPC.Models
{
    public class Produto
    {
        public int IdProduto { get; set; }

        public string Descricao { get; set; }

        public float Preco { get; set; }
    }
}
